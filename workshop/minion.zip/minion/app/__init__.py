from app.config import Config
import os, logging

global config
global misc

config = Config()

